/* eslint-disable */
import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)

import HelloWorld from '../components/HelloWorld.vue'
export function createRouter() {
    return new Router({
        mode: 'history',
        routes: [{
                path: '/',
                // component: HelloWorld
                component: () =>
                    import ('../components/HelloWorld.vue')
            },
            {
                path: '/item/:id',
                component: () =>
                    import ('../components/Item.vue')
            }
        ]
    })
}
