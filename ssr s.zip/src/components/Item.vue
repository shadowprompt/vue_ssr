<template>
  <div>{{item}}</div>
</template>
<script>
export default {
  created(){
    console.log(this);
  },
  asyncData ({ store, route }) {
    // 触发 action 后，会返回 Promise
    return store.dispatch('fetchItem', route.params.id)
  },
  computed: {
    // 从 store 的 state 对象中的获取 item。
    item () {
      console.log(this.$store.state.items);
      console.log(this.$route.params.id);
      return this.$store.state.items[this.$route.params.id]
    }
  }
}
</script>
